#ifndef _operand_h_
#define _operand_h_

#include "element.h"
#include <string>

class Operand : public Element {
	char vrsta;
public:
	Operand(string s){
		natpis = s; 
		vrsta = 'D';
	}
	Operand* kopiraj()const override{ return new Operand(*this); }
	char dohvVrsta()const override{ return vrsta; }
};

#endif // !_operand_h_
