#include "lista.h"
#include "element.h"
#include "greska.h"
#include "binOperator.h"
#include "desnaZagrada.h"
#include "izraz.h"
#include "levaZagrada.h"
#include "postfixGen.h"
#include "sabiranje.h"
#include "operand.h"
#include "Header.h"
#include<iostream>

int main() {
	try{
	Sabiranje s1;
	Mnozenje m1;
	Operand o1("s");
	Operand o2("k");
	LevaZagrada l1;
	DesnaZagrada l2;
	Izraz l;
	l += o1;
	l += m1;
	l += o2;
	Izraz* l22 = l.kopiraj();
	cout << *l22 << endl;
	l += s1;
	l += l1;
	l += o1;
	l += s1;
	l += o2;
	l += l2;
	
	cout << l << endl;


	GeneratorPostfiksa& generator = GeneratorPostfiksa::DohvatiGenerator();
	Izraz* p = generator(l);
	cout << *p << endl;


}
catch (exception e) {
	cout << e.what() << endl;
}
	return 0;


}


/*
---------------------NIZ----------------------

template<typename T>
class Niz {
	T* niz;
	int dim;
	int poz;
public:

	Niz(int d = 10) {
		niz = new T[dim = d];
		poz = 0;
	}

	~Niz() {
		delete[] niz;
	}

	Niz& operator+=(const T& t) {
		if (poz == dim) throw GNemaMesta();
		niz[poz++] = t;
		return *this;
	}

	int velicina() const {
		return poz;
	}

	T& operator[](int i) {
		if (i < 0 || i >= dim) throw GIndeks();
		return niz[i];
	}

	const T& operator[](int i) const {
		return const_cast<Niz&>(*this)[i];
	}
};




--------------------------------LISTA----------------------------------


template<typename T>
class Lista {
	struct Elem {
		T pod;
		Elem* sled;
		Elem(const T& p, Elem* s = nullptr) {
			pod = p; sled = s;
		}
	};

	Elem* prvi, * posl;
	int br;
	mutable Elem* tek;

	void brisi();
	void kopiraj(const Lista& l);

	void premesti(Lista& l) {
		prvi = l.prvi; posl = l.posl;
		tek = l.tek;
		l.prvi = l.posl = nullptr;
	}

public:
	Lista() {
		prvi = posl = tek = nullptr;
		br = 0;
	}

	Lista(const Lista& l) {
		kopiraj(l);
	}

	Lista(Lista&& l) {
		premesti(l);
	}

	Lista& operator=(const Lista& l) {
		if (this != &l) {
			brisi();
			kopiraj(l);
		}
		return *this;
	}

	Lista& operator=(Lista&& l) {
		if (this != &l) {
			brisi();
			premesti(l);
		}
		return *this;
	}

	~Lista() {
		brisi();
	}

	Lista& dodaj(const T& t) {
		posl = (!prvi ? prvi : posl->sled) = new Elem(t);
		br++;
		return *this;
	}

	int broj() const { return br; }

	void naPrvi() const { tek = prvi; }
	void naSled() const {
		if(tek)
			tek = tek->sled;
	}

	bool imaTek() const {
		return tek != nullptr;
	}

	T& dohvPod() const {
		if (!tek) throw GNemaTek();
		return tek->pod;
	}
};

template<typename T>
void Lista<T>::brisi() {
	while (prvi) {
		Elem* stari = prvi;
		prvi = prvi->sled;
		delete stari;
	}
	posl = tek = nullptr;
}

template<typename T>
void Lista<T>::kopiraj(const Lista& l) {
	prvi = posl = tek = nullptr;
	for (Elem* temp = l.prvi; temp; temp = temp->sled) {
		posl = (!prvi ? prvi : posl->sled) = new Elem(temp->pod);
	}
}


--------------------------EVAL POSTFIX-----------------------------

int evaluatePostfix(char* exp)
{
	// Create a stack of capacity equal to expression size
	struct Stack* stack = createStack(strlen(exp));
	int i;

	// See if stack was created successfully
	if (!stack) return -1;

	// Scan all characters one by one
	for (i = 0; exp[i]; ++i)
	{
		// If the scanned character is an operand (number here),
		// push it to the stack.
		if (isdigit(exp[i]))
			push(stack, exp[i] - '0');

		// If the scanned character is an operator, pop two
		// elements from stack apply the operator
		else
		{
			int val1 = pop(stack);
			int val2 = pop(stack);
			switch (exp[i])
			{
			case '+': push(stack, val2 + val1); break;
			case '-': push(stack, val2 - val1); break;
			case '*': push(stack, val2 * val1); break;
			case '/': push(stack, val2/val1); break;
			}
		}
	}
	return pop(stack);
}

// Driver program to test above functions
int main()
{
	char exp[] = "231*+9-";
	cout<<"postfix evaluation: "<< evaluatePostfix(exp);
	return 0;
}


--------------------------MNOZENJE-----------------------------------


class Mnozenje : public BinOperator {
public:
	Mnozenje() {
		natpis = "*";
		prioritet = 2;
	}
	int dohvPrioritet()const override { return prioritet; }
	Mnozenje* kopiraj()const override { return new Mnozenje(*this); }
};



*/